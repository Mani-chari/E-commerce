package com.ecom.springboot.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class ProductEntity  implements Serializable {
	
	private static final long serialVersionUID = -2188040429853689911L;
	
	private int product_id;
    private String name;
    private CategoryEntity category;
    private Set<VariantEntity> variant;
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@ManyToOne
    @JoinColumn(name = "cat_ref_id")
	public CategoryEntity getCategory() {
		return category;
	}
	public void setCategory(CategoryEntity category) {
		this.category = category;
	}
	
	@OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
	public Set<VariantEntity> getVariant() {
		return variant;
	}
	public void setVariant(Set<VariantEntity> variant) {
		this.variant = variant;
	}
	
}
