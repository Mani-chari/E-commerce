package com.ecom.springboot.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecom.springboot.entity.UserEntity;
import com.ecom.springboot.repository.UserRepository;


@Controller
public class AppController {
	
	@Autowired
	private UserRepository userRepository;

	@RequestMapping(value={"/","/index"})
	String home(ModelMap modal) {
		modal.addAttribute("title", "Dear Learner");
		modal.addAttribute("message", "Welcome to SpringBoot");
		modal.addAttribute("test", "this is a test attribute");
		return "index";
	}
	
	@RequestMapping("/login")
	String login(ModelMap modal) {
		return "login";
	}

	@RequestMapping(value="/register", method=RequestMethod.GET)
	String register(ModelMap modal) {
		modal.addAttribute("listOfUser", userRepository.findAll());
		return "register";
	}
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	String registerTest(ModelMap modal,@RequestParam Map<String,String> requestParams) {
		modal.addAttribute("fname", requestParams.get("fname"));
		//System.out.println(requestParams.get("fname") + " : " + requestParams.get("lname") + " : " + requestParams.get("uname") + " : " + Encryptor.encryptString(requestParams.get("pass")));
		/*modal.addAttribute("lname", requestParams.get("lname"));
		modal.addAttribute("uname", requestParams.get("uname"));
		modal.addAttribute("pass", requestParams.get("pass"));*/
		
		UserEntity user = new UserEntity();
		user.setId(123);
		user.setFname(requestParams.get("fname"));
		user.setLname(requestParams.get("lname"));
		user.setUname(requestParams.get("uname"));
		user.setPass(requestParams.get("pass"));
		userRepository.save(user);
		modal.addAttribute("listOfUser", userRepository.findAll());
		return "register";
	}
	
	@RequestMapping(value="/userlist", method=RequestMethod.GET)
	String userlist(ModelMap modal) {
		modal.addAttribute("listOfUser", userRepository.findAll());
		return "userlist";
	}
	
	@RequestMapping("*")
	String fallbackMethod(){
		return "404";
	}
}
