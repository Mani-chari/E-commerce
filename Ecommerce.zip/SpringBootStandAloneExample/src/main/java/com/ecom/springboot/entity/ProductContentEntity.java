package com.ecom.springboot.entity;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name="product_content")
public class ProductContentEntity implements Serializable {

	private static final long serialVersionUID = -5780550999564672645L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int content_id;
	private String img_url;
	private String description;
	private String slogan;
	
	@OneToOne(fetch = FetchType.LAZY,
            cascade =  CascadeType.ALL,
            mappedBy = "productContentEntity")
	private VariantEntity variant;
	
	public int getContent_id() {
		return content_id;
	}
	public void setContent_id(int content_id) {
		this.content_id = content_id;
	}
	public String getImg_url() {
		return img_url;
	}
	public void setImg_url(String img_url) {
		this.img_url = img_url;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSlogan() {
		return slogan;
	}
	public void setSlogan(String slogan) {
		this.slogan = slogan;
	}
	
	public VariantEntity getVariant() {
		return variant;
	}
	public void setVariant(VariantEntity variant) {
		this.variant = variant;
	}	
}
