package com.ecom.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecom.springboot.entity.VariantEntity;

public interface VariantRepository extends JpaRepository<VariantEntity, Integer> {

}
