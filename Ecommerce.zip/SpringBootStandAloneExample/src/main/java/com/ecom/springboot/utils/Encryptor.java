package com.ecom.springboot.utils;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Encryptor {
	public static String encryptString(String pEnString){
		 BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
	        return encoder.encode(pEnString);
				
	}
	public static boolean decryptString(String pEnString){
		 BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		 String encodedPassword = "123";
	        return encoder.matches(pEnString, encodedPassword);
				
	}
}
