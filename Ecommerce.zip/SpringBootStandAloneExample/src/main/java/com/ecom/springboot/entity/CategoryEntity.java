package com.ecom.springboot.entity;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Set;

@Entity
@Table(name = "categories")
public class CategoryEntity  implements Serializable {
	
	private static final long serialVersionUID = 3837686756698069584L;
	
	private int cat_id;
	private String cat_name;
	private String cat_description;
	private Set<ProductEntity> product;
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	public int getCat_id() {
		return cat_id;
	}
	public void setCat_id(int cat_id) {
		this.cat_id = cat_id;
	}
	public String getCat_name() {
		return cat_name;
	}
	public void setCat_name(String cat_name) {
		this.cat_name = cat_name;
	}
	public String getCat_description() {
		return cat_description;
	}
	public void setCat_description(String cat_description) {
		this.cat_description = cat_description;
	}
	
	@OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
	public Set<ProductEntity> getProduct() {
		return product;
	}
	public void setProduct(Set<ProductEntity> product) {
		this.product = product;
	}

}
