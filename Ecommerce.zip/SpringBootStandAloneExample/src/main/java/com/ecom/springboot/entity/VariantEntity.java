package com.ecom.springboot.entity;

import java.io.Serializable;

import javax.persistence.*;


@Entity
@Table(name="variant")
public class VariantEntity  implements Serializable {

		private static final long serialVersionUID = 3076694063662029834L;
		
		private int var_id;
		private String color;
		private double size;
		private ProductEntity product;
		private PriceEntity price;
		private ProductContentEntity productContentEntity;
		
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		public int getVar_id() {
			return var_id;
		}
		public void setVar_id(int var_id) {
			this.var_id = var_id;
		}
		public String getColor() {
			return color;
		}
		public void setColor(String color) {
			this.color = color;
		}
		public double getSize() {
			return size;
		}
		public void setSize(double size) {
			this.size = size;
		}
		
		@ManyToOne
	    @JoinColumn(name = "product_ref_id")
		public ProductEntity getProduct() {
			return product;
		}
		public void setProduct(ProductEntity product) {
			this.product = product;
		}
		
		@OneToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "price_ref_id", nullable = false)
		public PriceEntity getPrice() {
			return price;
		}
		public void setPrice(PriceEntity price) {
			this.price = price;
		}
		
		@OneToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "cont_ref_id", nullable = false)
		public ProductContentEntity getProductContentEntity() {
			return productContentEntity;
		}
		public void setProductContentEntity(ProductContentEntity productContentEntity) {
			this.productContentEntity = productContentEntity;
		}
}
