package com.ecom.springboot.entity;

import java.io.Serializable;

import javax.persistence.*;


@Entity
@Table(name="price")
public class PriceEntity  implements Serializable {
	
	private static final long serialVersionUID = -8308282297246095161L;
	
	private int price_id;
	private double price_val;
	private String price_type;
	private String currency_type;
	
	@OneToOne(fetch = FetchType.LAZY,
            cascade =  CascadeType.ALL,
            mappedBy = "price_ref_id")
	private VariantEntity varaint;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getPrice_id() {
		return price_id;
	}
	public void setPrice_id(int price_id) {
		this.price_id = price_id;
	}
	public double getPrice_val() {
		return price_val;
	}
	public void setPrice_val(double price_val) {
		this.price_val = price_val;
	}
	public String getPrice_type() {
		return price_type;
	}
	public void setPrice_type(String price_type) {
		this.price_type = price_type;
	}
	public String getCurrency_type() {
		return currency_type;
	}
	public void setCurrency_type(String currency_type) {
		this.currency_type = currency_type;
	}
	public VariantEntity getVaraint() {
		return varaint;
	}
	public void setVaraint(VariantEntity varaint) {
		this.varaint = varaint;
	}
}
