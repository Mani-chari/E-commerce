package com.ecom.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ecom.springboot.repository.CategoryRepository;
import com.ecom.springboot.repository.ProductRepository;
import com.ecom.springboot.repository.VariantRepository;

@Controller
public class ProductController {
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private VariantRepository variantRepository;

	@RequestMapping(value="/products", method=RequestMethod.GET)
	String products(ModelMap modal) {
		modal.addAttribute("categoryList",categoryRepository.findAll());
		modal.addAttribute("productList",productRepository.findAll());
		System.out.println(" category : "+categoryRepository.findAll());
		System.out.println(" Variant : "+productRepository.findAll());
		return "products";
	}
	
	@RequestMapping(value="/shoppingCart", method=RequestMethod.GET)
	String shoppingCart(ModelMap modal) {
	
		return "shoppingCart";
	}

}
